# py-dicio-api
Aula do dia 25/09 de Estrutura de Dados - API com Python 

### Na pasta 'dicionarios', o exemplo.py é uma Introdução a Dicionários em Python 

## Integração de Python com API 

**Doc:** https://realpython.com/api-integration-in-python/

### Pasta 'aula2509' - Introdução a Integração da API de Vinícola em Python

### Passo a Passo

1. `` python -m pip install requests ``
2. Arquivo **'teste.py'** que irá trazer os registros de marcas da API da Vinícola através do Python, arquivo com exemplos de funções (estão comentados no código os títulos)
